import type { Config } from '@netlify/functions';
import { SimpleRateLimiter } from '../../src/server/rateLimiter.ts';
import {
  handleEmailCheck, handlePwnedRange, handleCombo, handleBreaches, handleThreatStats, ApiResult
} from '../../src/server/handlers.ts';

// Limiteur en mémoire (par instance de fonction : protection « best effort »)
const limiter = new SimpleRateLimiter(60000, 1000);

const json = (r: ApiResult, extra: Record<string, string> = {}) =>
  new Response(JSON.stringify(r.body), {
    status: r.status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'X-Content-Type-Options': 'nosniff', ...(r.headers || {}), ...extra }
  });

const NO_CACHE = { 'Cache-Control': 'no-store, no-cache, must-revalidate, private', Pragma: 'no-cache', Expires: '0' };

export default async (req: Request): Promise<Response> => {
  const url = new URL(req.url);
  const path = url.pathname.replace(/\/+$/, '');
  const method = req.method.toUpperCase();

  if (method === 'OPTIONS') return new Response(null, { status: 204 });

  const sensitive = path.startsWith('/api/check/');
  let extra: Record<string, string> = {};
  if (sensitive) {
    const ip = req.headers.get('x-nf-client-connection-ip') || req.headers.get('x-forwarded-for')?.split(',')[0].trim() || 'unknown';
    const rl = limiter.check(ip);
    if (!rl.allowed) {
      return json(
        { status: 429, body: { error: "Trop de requêtes effectuées. Veuillez patienter avant de renouveler l'audit.", retryAfterSec: rl.retryAfterSec } },
        { 'Retry-After': String(rl.retryAfterSec || 60) }
      );
    }
    extra = { ...NO_CACHE, 'X-RateLimit-Remaining': String(rl.remaining) };
  }

  try {
    if (method === 'GET' && path.startsWith('/api/check/pwned-range/')) {
      return json(await handlePwnedRange(decodeURIComponent(path.split('/').pop() || '')), extra);
    }
    if (method === 'POST' && path === '/api/check/email') {
      const body = await req.json().catch(() => ({}));
      return json(await handleEmailCheck((body as any)?.email), extra);
    }
    if (method === 'POST' && path === '/api/check/combo') {
      const body = await req.json().catch(() => ({}));
      return json(handleCombo(body || {}), extra);
    }
    if (method === 'GET' && path === '/api/breaches') return json(handleBreaches());
    if (method === 'GET' && path === '/api/threat-stats') return json(handleThreatStats());
  } catch (err) {
    console.error('[CyberLeak Guard] Erreur fonction API:', err);
    return json({ status: 500, body: { error: 'Erreur interne du service.' } }, extra);
  }

  return json({ status: 404, body: { error: 'Route API inconnue.' } });
};

export const config: Config = { path: '/api/*' };
