import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { SimpleRateLimiter } from './src/server/rateLimiter.ts';
import {
  handleEmailCheck, handlePwnedRange, handleCombo, handleBreaches, handleThreatStats,
  refreshBreachesCatalog, ApiResult
} from './src/server/handlers.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const HOST = '0.0.0.0';

// Catalogue des brèches : préchargement + rafraîchissement périodique (serveur persistant)
refreshBreachesCatalog();

// Anti-abuse rate limiter: 1000 requests per minute per IP
const apiRateLimiter = new SimpleRateLimiter(60000, 1000);
setInterval(() => apiRateLimiter.cleanup(), 300000);

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});

app.use(cors());
app.use(express.json({ limit: '64kb' }));

const checkRateLimit = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0].trim() || req.ip || '127.0.0.1';
  const { allowed, remaining, retryAfterSec } = apiRateLimiter.check(clientIp);
  res.setHeader('X-RateLimit-Remaining', remaining.toString());
  if (!allowed) {
    res.setHeader('Retry-After', (retryAfterSec || 60).toString());
    return res.status(429).json({
      error: 'Trop de requêtes effectuées. Veuillez patienter avant de renouveler l\'audit.',
      retryAfterSec
    });
  }
  next();
};

const noCache = (_req: express.Request, res: express.Response, next: express.NextFunction) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
};

const send = (res: express.Response, r: ApiResult) => {
  if (r.headers) for (const [k, v] of Object.entries(r.headers)) res.setHeader(k, v);
  return res.status(r.status).json(r.body);
};

app.get('/api/check/pwned-range/:prefix', checkRateLimit, noCache, async (req, res) => send(res, await handlePwnedRange(req.params.prefix)));
app.post('/api/check/email', checkRateLimit, noCache, async (req, res) => send(res, await handleEmailCheck(req.body?.email)));
app.post('/api/check/combo', checkRateLimit, noCache, (req, res) => send(res, handleCombo(req.body || {})));
app.get('/api/breaches', (_req, res) => send(res, handleBreaches()));
app.get('/api/threat-stats', (_req, res) => send(res, handleThreatStats()));

// Mount Vite or static server
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        host: HOST,
        port: PORT,
        allowedHosts: true
      },
      appType: 'spa'
    });

    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, HOST, () => {
    console.log(`[CyberLeak Guard] Server running securely on http://${HOST}:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
