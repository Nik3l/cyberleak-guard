/**
 * Logique d'API partagée (Express en local + Netlify Function en production).
 * Fonctions pures : aucune dépendance à Express.
 */
import { KNOWN_BREACHES, CURRENT_STATS, DataBreach } from '../data/breaches.ts';
import { sanitizeAndValidateEmail, validateHashPrefix } from '../utils/validation.ts';
import { SimpleTTLCache } from './rateLimiter.ts';

export const APP_VERSION = '1.2';

export interface ApiResult {
  status: number;
  body: unknown;
  headers?: Record<string, string>;
}

const emailBreachCache = new SimpleTTLCache<any>(1000);
const pwnedRangeCache = new SimpleTTLCache<string>(5000);

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) CyberLeak-Guard/' + APP_VERSION;

// ---------- Catalogue des brèches (graine locale + XposedOrNot) ----------
const breachesCatalogMap = new Map<string, any>();

for (const b of KNOWN_BREACHES) {
  breachesCatalogMap.set(b.id.toLowerCase(), {
    breachID: b.id,
    breachedDate: b.breachDate,
    domain: b.domain,
    exposedRecords: b.pwnCount,
    exposureDescription: b.description,
    exposedData: b.dataClasses,
    verified: b.isVerified,
    passwordRisk: b.dataClasses.some(dc => dc.toLowerCase().includes('password') || dc.toLowerCase().includes('mot de passe')) ? 'plaintext' : 'unknown'
  });
  breachesCatalogMap.set(b.name.toLowerCase(), breachesCatalogMap.get(b.id.toLowerCase()));
}

let catalogLoadedAt = 0;
let catalogLastAttempt = 0;
const CATALOG_TTL = 6 * 3600 * 1000;
const CATALOG_RETRY = 10 * 60 * 1000;

export async function refreshBreachesCatalog(): Promise<void> {
  const now = Date.now();
  if (now - catalogLoadedAt < CATALOG_TTL || now - catalogLastAttempt < CATALOG_RETRY) return;
  catalogLastAttempt = now;
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4000);
    const res = await fetch('https://api.xposedornot.com/v1/breaches', {
      headers: { 'User-Agent': UA },
      signal: controller.signal
    });
    clearTimeout(timer);
    if (res.ok) {
      const data: any = await res.json();
      if (Array.isArray(data.exposedBreaches)) {
        for (const b of data.exposedBreaches) {
          if (b.breachID) {
            breachesCatalogMap.set(b.breachID.toLowerCase(), b);
            breachesCatalogMap.set(b.breachID.toLowerCase().replace(/[^a-z0-9]/g, '-'), b);
          }
        }
        catalogLoadedAt = Date.now();
        console.log(`[CyberLeak Guard] Catalogue mis à jour (${breachesCatalogMap.size} entrées).`);
      }
    }
  } catch (err: any) {
    console.warn('[CyberLeak Guard] Catalogue distant indisponible, entrées locales utilisées:', err?.message || err);
  }
}

function resolveBreachMeta(name: string): DataBreach {
  const lowerName = name.toLowerCase();
  const meta = breachesCatalogMap.get(lowerName) ||
    breachesCatalogMap.get(lowerName.replace(/[^a-z0-9]/g, '-')) ||
    KNOWN_BREACHES.find(kb => kb.id.toLowerCase() === lowerName || kb.name.toLowerCase() === lowerName);

  const dataClasses: string[] = Array.isArray(meta?.exposedData)
    ? meta.exposedData
    : meta?.dataClasses || ['Adresses e-mail'];

  const hasPasswords = dataClasses.some((dc: string) =>
    dc.toLowerCase().includes('password') || dc.toLowerCase().includes('mot de passe')
  ) || meta?.passwordRisk === 'plaintext' || meta?.passwordRisk === 'easytocrack';

  let severity: 'Critical' | 'High' | 'Medium' | 'Low' = 'Medium';
  if (hasPasswords) severity = 'Critical';
  else if (dataClasses.length > 3) severity = 'High';

  let remediationAdvice = 'Modifiez le mot de passe utilisé sur ce service et activez la double authentification.';
  if (hasPasswords) {
    remediationAdvice = 'URGENT : Des mots de passe ont fuité dans cette brèche. Changez immédiatement ce mot de passe partout où il a pu être réutilisé.';
  } else if (dataClasses.some((dc: string) => dc.toLowerCase().includes('phone') || dc.toLowerCase().includes('téléphone'))) {
    remediationAdvice = 'Numéro de téléphone exposé : Méfiez-vous des SMS et appels frauduleux (smishing, faux conseillers bancaires).';
  }

  return {
    id: name.toLowerCase().replace(/[^a-z0-9]/g, '-'),
    name: meta?.breachID || meta?.name || name,
    domain: meta?.domain || '',
    breachDate: meta?.breachedDate ? String(meta.breachedDate).split('T')[0] : (meta?.breachDate || 'Historique'),
    addedDate: meta?.addedDate || '',
    pwnCount: meta?.exposedRecords || meta?.pwnCount || 0,
    description: meta?.exposureDescription || meta?.description || `Données de compte compromises dans l'incident ${name}.`,
    dataClasses,
    isVerified: meta?.verified ?? true,
    isFabricated: false,
    isSensitive: meta?.sensitive ?? false,
    isSpamList: false,
    category: meta?.industry === 'Entertainment' || meta?.category === 'Entertainment' ? 'Entertainment' :
      meta?.industry === 'Social' || meta?.category === 'Social' ? 'Social' :
      meta?.industry === 'Government' ? 'Finance' : 'Tech',
    severity,
    remediationAdvice
  };
}

function isDemoEmail(email: string): boolean {
  return email.includes('test-leak') || email.includes('compromised-demo') || email.includes('leaked@');
}

function buildEmailResult(email: string, breaches: DataBreach[]) {
  const passwordsLeakedCount = breaches.filter(b =>
    b.dataClasses.some(dc => dc.toLowerCase().includes('password') || dc.toLowerCase().includes('mot de passe'))
  ).length;
  const riskLevel = breaches.some(b => b.severity === 'Critical') || passwordsLeakedCount > 0
    ? 'Critical'
    : breaches.length > 0 ? 'High' : 'Safe';
  return {
    email,
    breached: breaches.length > 0,
    breachCount: breaches.length,
    passwordsLeakedCount,
    pasteCount: 0,
    breaches,
    riskLevel,
    checkedAt: new Date().toISOString()
  };
}

const UNAVAILABLE: ApiResult = {
  status: 503,
  body: { error: "Le service de vérification des fuites est momentanément indisponible. Aucun résultat n'a été établi : veuillez réessayer dans quelques instants." }
};

// ---------- Handlers ----------
export async function handleEmailCheck(rawEmail: unknown): Promise<ApiResult> {
  const validation = sanitizeAndValidateEmail(rawEmail);
  if (!validation.valid || !validation.email) {
    return { status: 400, body: { error: validation.error || 'Veuillez saisir une adresse e-mail valide.' } };
  }
  const cleanEmail = validation.email.toLowerCase();

  const cached = emailBreachCache.get(cleanEmail);
  if (cached) return { status: 200, body: { ...cached, cached: true } };

  try {
    // Adresses de démonstration : réponse locale, sans appel externe
    if (isDemoEmail(cleanEmail)) {
      await refreshBreachesCatalog();
      const result = buildEmailResult(cleanEmail, ['collection-1', 'naz-api', 'comb-3b'].map(resolveBreachMeta));
      emailBreachCache.set(cleanEmail, result, 600000);
      return { status: 200, body: result };
    }

    const lookup = (async (): Promise<string[] | null> => {
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 2800);
        const r = await fetch(`https://api.xposedornot.com/v1/check-email/${encodeURIComponent(cleanEmail)}`, {
          headers: { 'User-Agent': UA },
          signal: controller.signal
        });
        clearTimeout(timeout);
        if (r.status === 404) return []; // XposedOrNot : "Not found" = aucune fuite
        if (!r.ok) return null;
        const data: any = await r.json();
        if (data.Error === 'Not found' || !data.breaches) return [];
        if (Array.isArray(data.breaches) && Array.isArray(data.breaches[0])) return data.breaches[0] as string[];
        return [];
      } catch (e: any) {
        console.warn('[CyberLeak Guard] Vérification email échouée:', e?.message || e);
        return null;
      }
    })();

    const [names] = await Promise.all([lookup, refreshBreachesCatalog()]);

    if (names === null) {
      // Ne JAMAIS répondre « sûr » si la vérification n'a pas abouti
      return UNAVAILABLE;
    }

    const result = buildEmailResult(cleanEmail, names.map(resolveBreachMeta));
    emailBreachCache.set(cleanEmail, result, 600000);
    return { status: 200, body: result };
  } catch (err: any) {
    console.error('[CyberLeak Guard] Erreur /api/check/email:', err);
    return UNAVAILABLE;
  }
}

export async function handlePwnedRange(rawPrefix: unknown): Promise<ApiResult> {
  const validation = validateHashPrefix(rawPrefix);
  if (!validation.valid || !validation.prefix) {
    return { status: 400, body: { error: validation.error } };
  }
  const prefix = validation.prefix;

  const cachedData = pwnedRangeCache.get(prefix);
  if (cachedData) return { status: 200, body: { data: cachedData, cached: true } };

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6000);
    const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`, {
      headers: { 'Add-Padding': 'true', 'User-Agent': 'CyberLeak-Guard-Platform' },
      signal: controller.signal
    });
    clearTimeout(timeout);
    if (!response.ok) {
      return { status: response.status, body: { error: 'Erreur lors de la requête vers le service k-anonymat' } };
    }
    const data = await response.text();
    pwnedRangeCache.set(prefix, data, 3600000);
    return { status: 200, body: { data, cached: false } };
  } catch (err) {
    console.error('Error fetching pwned range:', err);
    return { status: 502, body: { error: 'Impossible de joindre le service de vérification k-anonymat' } };
  }
}

export function handleCombo(body: any): ApiResult {
  const emailValidation = sanitizeAndValidateEmail(body?.email);
  if (!emailValidation.valid || !emailValidation.email) {
    return { status: 400, body: { error: emailValidation.error } };
  }
  const { passwordPwned, passwordPwnedCount, passwordLength, emailBreached, emailBreachCount, passwordsLeakedCount } = body;

  const cleanEmail = emailValidation.email;
  const safePwCount = typeof passwordPwnedCount === 'number' ? Math.max(0, passwordPwnedCount) : 0;
  const safePwLength = typeof passwordLength === 'number' ? Math.max(0, passwordLength) : 0;

  let credentialStuffingRisk: 'Critical' | 'High' | 'Medium' | 'Low' = 'Low';
  let securityScore = 95;
  const riskFactors: string[] = [];
  const positiveFactors: string[] = [];

  if (passwordPwned) {
    if (safePwCount > 50000) {
      securityScore = Math.min(securityScore, 20);
      riskFactors.push(`Ce mot de passe est répertorié ${safePwCount.toLocaleString()} fois dans les dictionnaires d'attaque brute-force.`);
    } else {
      securityScore = Math.min(securityScore, 35);
      riskFactors.push(`Ce mot de passe apparaît déjà dans ${safePwCount.toLocaleString()} fuites de données.`);
    }
  } else {
    positiveFactors.push('Ce mot de passe n\'apparaît dans aucune fuite publique répertoriée (K-Anonymat vérifié).');
  }

  if (emailBreached) {
    riskFactors.push(`L'adresse e-mail a été trouvée dans ${emailBreachCount || 0} fuite(s) de données réelles.`);
    if (passwordsLeakedCount && passwordsLeakedCount > 0) {
      riskFactors.push(`Des mots de passe ont été divulgués dans au moins ${passwordsLeakedCount} de ces fuites.`);
    }
  } else {
    positiveFactors.push('L\'adresse e-mail n\'apparaît dans aucune fuite majeure répertoriée.');
  }

  if (safePwLength < 10) {
    securityScore = Math.max(5, securityScore - 25);
    riskFactors.push('Longueur de mot de passe faible (< 10 caractères) pouvant être cassée très rapidement.');
  } else if (safePwLength >= 16) {
    securityScore = Math.min(100, securityScore + 10);
    positiveFactors.push('Longueur de mot de passe excellente (≥ 16 caractères).');
  }

  if (passwordPwned && emailBreached) {
    credentialStuffingRisk = 'Critical';
    securityScore = Math.min(15, securityScore);
    riskFactors.unshift('DANGER CRITIQUE DE BOURRAGE D\'IDENTIFIANTS : Votre e-mail ET ce mot de passe sont tous deux dans des fuites. Les attaquants testent régulièrement ces combinaisons.');
  } else if (passwordPwned && !emailBreached) {
    credentialStuffingRisk = 'High';
    securityScore = Math.min(45, securityScore);
    riskFactors.unshift('RISQUE ÉLEVÉ : Le mot de passe est compromis et vulnérable aux attaques par dictionnaire.');
  } else if (!passwordPwned && emailBreached) {
    credentialStuffingRisk = 'Medium';
    securityScore = Math.min(75, Math.max(55, securityScore));
    positiveFactors.unshift('POINT RASSURANT : Bien que votre e-mail ait fuité par le passé, CE mot de passe est vierge de fuite. Ne réutilisez jamais un ancien mot de passe.');
  } else {
    credentialStuffingRisk = 'Low';
    securityScore = 98;
    positiveFactors.unshift('SÉCURITÉ OPTIMALE : Ni votre e-mail ni votre mot de passe ne sont répertoriés dans les fuites.');
  }

  return {
    status: 200,
    body: {
      email: cleanEmail,
      credentialStuffingRisk,
      securityScore,
      riskFactors,
      positiveFactors,
      isComboExposed: Boolean(passwordPwned && emailBreached),
      analyzedAt: new Date().toISOString()
    }
  };
}

export function handleBreaches(): ApiResult {
  return { status: 200, body: { breaches: KNOWN_BREACHES }, headers: { 'Cache-Control': 'public, max-age=3600' } };
}

export function handleThreatStats(): ApiResult {
  return { status: 200, body: CURRENT_STATS, headers: { 'Cache-Control': 'public, max-age=1800' } };
}
