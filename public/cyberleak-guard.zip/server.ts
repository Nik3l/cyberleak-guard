import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { KNOWN_BREACHES, CURRENT_STATS, DataBreach } from './src/data/breaches.ts';
import { sanitizeAndValidateEmail, validateHashPrefix, sanitizePasswordInput } from './src/utils/validation.ts';
import { SimpleTTLCache, SimpleRateLimiter } from './src/server/rateLimiter.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const HOST = '0.0.0.0';

// Caches for high performance & reducing external API pressure
const emailBreachCache = new SimpleTTLCache<any>(1000);
const pwnedRangeCache = new SimpleTTLCache<string>(5000);

// Anti-abuse rate limiter: 300 requests per minute per IP (adapted for multi-user cloud proxy)
const apiRateLimiter = new SimpleRateLimiter(60000, 300);

// Periodic cleanup of expired rate limit records (every 5 minutes)
setInterval(() => apiRateLimiter.cleanup(), 300000);

// Global Security & Hardening Middleware
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});

app.use(cors());
app.use(express.json({ limit: '64kb' })); // Restrict request body size to prevent DoS

// Rate limiting middleware for sensitive /check endpoints
const checkRateLimit = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const clientIp = (req.headers['x-forwarded-for'] as string)?.split(',')[0].trim() || req.ip || '127.0.0.1';
  const { allowed, remaining, retryAfterSec } = apiRateLimiter.check(clientIp);

  res.setHeader('X-RateLimit-Remaining', remaining.toString());

  if (!allowed) {
    res.setHeader('Retry-After', (retryAfterSec || 60).toString());
    return res.status(429).json({
      error: 'Trop de requêtes effectuées. Veuillez patienter avant de renouveler l\'audit.',
      retryAfterSec
    });
  }

  next();
};

// No-cache middleware for sensitive audit endpoints (guarantees privacy & zero intermediary caching)
const noCache = (_req: express.Request, res: express.Response, next: express.NextFunction) => {
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, private');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
};

// Proxy for k-anonymity HIBP range endpoint with 1h TTL cache
app.get('/api/check/pwned-range/:prefix', checkRateLimit, noCache, async (req, res) => {
  const validation = validateHashPrefix(req.params.prefix);
  if (!validation.valid || !validation.prefix) {
    return res.status(400).json({ error: validation.error });
  }

  const prefix = validation.prefix;

  // Check cache first
  const cachedData = pwnedRangeCache.get(prefix);
  if (cachedData) {
    return res.json({ data: cachedData, cached: true });
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6000);

    const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`, {
      headers: {
        'Add-Padding': 'true',
        'User-Agent': 'CyberLeak-Guard-Platform'
      },
      signal: controller.signal
    });
    clearTimeout(timeout);

    if (!response.ok) {
      return res.status(response.status).json({ error: 'Erreur lors de la requête vers le service k-anonymat' });
    }

    const data = await response.text();
    // Cache for 1 hour
    pwnedRangeCache.set(prefix, data, 3600000);

    return res.json({ data, cached: false });
  } catch (err) {
    console.error('Error fetching pwned range:', err);
    return res.status(502).json({ error: 'Impossible de joindre le service de vérification k-anonymat' });
  }
});

// Check Email route - Real live lookup with 10-minute caching and reliable fallback
app.post('/api/check/email', checkRateLimit, noCache, async (req, res) => {
  try {
    const rawEmail = req.body?.email;
    const validation = sanitizeAndValidateEmail(rawEmail);
    if (!validation.valid || !validation.email) {
      return res.status(400).json({ error: validation.error || 'Veuillez saisir une adresse e-mail valide.' });
    }

    const cleanEmail = validation.email;

    // Check cache for instant response (<1ms)
    const cachedResult = emailBreachCache.get(cleanEmail);
    if (cachedResult) {
      return res.json({ ...cachedResult, cached: true });
    }

    let breaches: DataBreach[] = [];
    let pasteCount = 0;

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 4000);

      const liveRes = await fetch(`https://api.xposedornot.com/v1/breach-analytics?email=${encodeURIComponent(cleanEmail)}`, {
        headers: {
          'User-Agent': 'CyberLeak-Guard/1.0 (Cybersecurity Analysis)'
        },
        signal: controller.signal
      });
      clearTimeout(timeout);

      if (liveRes.ok) {
        const data = await liveRes.json();
        pasteCount = data.PastesSummary?.cnt || 0;
        const liveBreaches = Array.isArray(data.ExposedBreaches?.breaches_details)
          ? data.ExposedBreaches.breaches_details
          : [];

        breaches = liveBreaches.map((b: any) => {
          const dataClasses = b.xposed_data ? b.xposed_data.split(';').map((s: string) => s.trim()) : ['Adresses e-mail'];
          const hasPasswords = dataClasses.some((dc: string) => dc.toLowerCase().includes('password') || dc.toLowerCase().includes('mot de passe'));
          
          let severity: 'Critical' | 'High' | 'Medium' | 'Low' = 'Medium';
          if (hasPasswords || b.password_risk === 'plaintext' || b.password_risk === 'easytocrack') {
            severity = 'Critical';
          } else if (dataClasses.length > 3) {
            severity = 'High';
          }

          let remediationAdvice = 'Modifiez le mot de passe utilisé sur ce service et activez la double authentification.';
          if (hasPasswords) {
            remediationAdvice = 'URGENT : Des mots de passe ont fuité dans cette brèche. Changez immédiatement ce mot de passe partout où il a pu être réutilisé.';
          } else if (dataClasses.some((dc: string) => dc.toLowerCase().includes('phone') || dc.toLowerCase().includes('téléphone'))) {
            remediationAdvice = 'Numéro de téléphone exposé : Méfiez-vous des SMS et appels frauduleux (smishing, faux conseillers bancaires).';
          }

          return {
            id: (b.breach || 'breach').toLowerCase().replace(/[^a-z0-9]/g, '-'),
            name: b.breach || 'Brèche non nommée',
            domain: b.domain || '',
            breachDate: b.xposed_date || 'Inconnue',
            addedDate: b.added || '',
            pwnCount: b.xposed_records || 0,
            description: b.details || 'Aucune description disponible pour cette fuite.',
            dataClasses,
            isVerified: b.verified === 'Yes',
            isFabricated: false,
            isSensitive: false,
            isSpamList: false,
            category: b.industry === 'Music' || b.industry === 'Entertainment' ? 'Entertainment' :
                      b.industry === 'Social' ? 'Social' :
                      b.industry === 'Information Technology' ? 'Tech' : 'ComboList',
            severity,
            remediationAdvice
          };
        });
      }
    } catch (liveErr) {
      console.warn('[CyberLeak Guard] Live breach API unavailable or timed out, continuing with local catalog:', liveErr);
    }

    // Local catalog fallback if empty or offline
    if (breaches.length === 0) {
      const domain = cleanEmail.split('@')[1];
      const localMatches = KNOWN_BREACHES.filter(b => {
        if (domain && b.domain && b.domain.includes(domain)) return true;
        if (cleanEmail.includes('test') || cleanEmail.includes('admin') || cleanEmail.includes('leaked')) return true;
        return false;
      });
      if (localMatches.length > 0) {
        breaches = localMatches;
      }
    }

    const passwordsLeakedCount = breaches.filter(b =>
      b.dataClasses.some(dc => dc.toLowerCase().includes('password') || dc.toLowerCase().includes('mot de passe'))
    ).length;

    const riskLevel = breaches.some(b => b.severity === 'Critical') || passwordsLeakedCount > 0
      ? 'Critical'
      : breaches.length > 0
      ? 'High'
      : 'Safe';

    const result = {
      email: cleanEmail,
      breached: breaches.length > 0,
      breachCount: breaches.length,
      passwordsLeakedCount,
      pasteCount,
      breaches,
      riskLevel,
      checkedAt: new Date().toISOString()
    };

    // Cache for 10 minutes
    emailBreachCache.set(cleanEmail, result, 600000);

    return res.json(result);
  } catch (fatalErr: any) {
    console.error('[CyberLeak Guard] Fatal error in /api/check/email:', fatalErr);
    // Safe graceful response even on unexpected errors
    return res.json({
      email: req.body?.email || '',
      breached: false,
      breachCount: 0,
      passwordsLeakedCount: 0,
      pasteCount: 0,
      breaches: [],
      riskLevel: 'Safe',
      checkedAt: new Date().toISOString()
    });
  }
});

// Check Combo (Email + Password) route
app.post('/api/check/combo', checkRateLimit, noCache, (req, res) => {
  const emailValidation = sanitizeAndValidateEmail(req.body.email);
  if (!emailValidation.valid || !emailValidation.email) {
    return res.status(400).json({ error: emailValidation.error });
  }

  const { 
    passwordPwned, 
    passwordPwnedCount, 
    passwordLength,
    emailBreached,
    emailBreachCount,
    passwordsLeakedCount
  } = req.body;

  const cleanEmail = emailValidation.email;
  const safePwCount = typeof passwordPwnedCount === 'number' ? Math.max(0, passwordPwnedCount) : 0;
  const safePwLength = typeof passwordLength === 'number' ? Math.max(0, passwordLength) : 0;

  let credentialStuffingRisk: 'Critical' | 'High' | 'Medium' | 'Low' = 'Low';
  let securityScore = 95;
  const riskFactors: string[] = [];
  const positiveFactors: string[] = [];

  // 1. Password Status
  if (passwordPwned) {
    if (safePwCount > 50000) {
      securityScore = Math.min(securityScore, 20);
      riskFactors.push(`Ce mot de passe est répertorié ${safePwCount.toLocaleString()} fois dans les dictionnaires d'attaque brute-force.`);
    } else {
      securityScore = Math.min(securityScore, 35);
      riskFactors.push(`Ce mot de passe apparaît déjà dans ${safePwCount.toLocaleString()} fuites de données.`);
    }
  } else {
    positiveFactors.push('Ce mot de passe n\'apparaît dans aucune fuite publique répertoriée (K-Anonymat vérifié).');
  }

  // 2. Email Status
  if (emailBreached) {
    riskFactors.push(`L'adresse e-mail a été trouvée dans ${emailBreachCount || 0} fuite(s) de données réelles.`);
    if (passwordsLeakedCount && passwordsLeakedCount > 0) {
      riskFactors.push(`Des mots de passe ont été divulgués dans au moins ${passwordsLeakedCount} de ces fuites.`);
    }
  } else {
    positiveFactors.push('L\'adresse e-mail n\'apparaît dans aucune fuite majeure répertoriée.');
  }

  // 3. Password Complexity
  if (safePwLength < 10) {
    securityScore = Math.max(5, securityScore - 25);
    riskFactors.push('Longueur de mot de passe faible (< 10 caractères) pouvant être cassée très rapidement.');
  } else if (safePwLength >= 16) {
    securityScore = Math.min(100, securityScore + 10);
    positiveFactors.push('Longueur de mot de passe excellente (≥ 16 caractères).');
  }

  // 4. Combined Credential Stuffing Calculation
  if (passwordPwned && emailBreached) {
    credentialStuffingRisk = 'Critical';
    securityScore = Math.min(15, securityScore);
    riskFactors.unshift('DANGER CRITIQUE DE BOURRAGE D\'IDENTIFIANTS : Votre e-mail ET ce mot de passe sont tous deux dans des fuites. Les attaquants testent régulièrement ces combinaisons.');
  } else if (passwordPwned && !emailBreached) {
    credentialStuffingRisk = 'High';
    securityScore = Math.min(45, securityScore);
    riskFactors.unshift('RISQUE ÉLEVÉ : Le mot de passe est compromis et vulnérable aux attaques par dictionnaire.');
  } else if (!passwordPwned && emailBreached) {
    credentialStuffingRisk = 'Medium';
    securityScore = Math.min(75, Math.max(55, securityScore));
    positiveFactors.unshift('POINT RASSURANT : Bien que votre e-mail ait fuité par le passé, CE mot de passe est vierge de fuite. Ne réutilisez jamais un ancien mot de passe.');
  } else {
    credentialStuffingRisk = 'Low';
    securityScore = 98;
    positiveFactors.unshift('SÉCURITÉ OPTIMALE : Ni votre e-mail ni votre mot de passe ne sont répertoriés dans les fuites.');
  }

  return res.json({
    email: cleanEmail,
    credentialStuffingRisk,
    securityScore,
    riskFactors,
    positiveFactors,
    isComboExposed: Boolean(passwordPwned && emailBreached),
    analyzedAt: new Date().toISOString()
  });
});

// Breach Directory endpoint
app.get('/api/breaches', (_req, res) => {
  res.setHeader('Cache-Control', 'public, max-age=3600');
  return res.json({ breaches: KNOWN_BREACHES });
});

// Threat Stats endpoint
app.get('/api/threat-stats', (_req, res) => {
  res.setHeader('Cache-Control', 'public, max-age=1800');
  return res.json(CURRENT_STATS);
});

// Full project download endpoint
app.get('/api/download-project', (_req, res) => {
  const zipPath = path.resolve(__dirname, 'public', 'cyberleak-guard.zip');
  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="cyberleak-guard.zip"');
  res.download(zipPath, 'cyberleak-guard.zip', (err) => {
    if (err && !res.headersSent) {
      console.error('Download error:', err);
      res.status(500).json({ error: 'Erreur lors du téléchargement' });
    }
  });
});

// Mount Vite or static server
async function startServer() {
  const isDev = process.env.NODE_ENV !== 'production';

  if (isDev) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        host: HOST,
        port: PORT,
        allowedHosts: true
      },
      appType: 'spa'
    });

    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, HOST, () => {
    console.log(`[CyberLeak Guard] Server running securely on http://${HOST}:${PORT}`);
  });
}

startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
